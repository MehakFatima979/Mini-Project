﻿namespace FYP1
{
    partial class GroupEvaluation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridGroplist = new System.Windows.Forms.DataGridView();
            this.dataGridEvaluation = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtgroup = new System.Windows.Forms.TextBox();
            this.txtevaluation = new System.Windows.Forms.TextBox();
            this.txtmarks = new System.Windows.Forms.TextBox();
            this.dateTimedate = new System.Windows.Forms.DateTimePicker();
            this.btndone = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridGroplist)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridEvaluation)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridGroplist
            // 
            this.dataGridGroplist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridGroplist.Location = new System.Drawing.Point(10, 50);
            this.dataGridGroplist.Name = "dataGridGroplist";
            this.dataGridGroplist.Size = new System.Drawing.Size(289, 152);
            this.dataGridGroplist.TabIndex = 0;
            // 
            // dataGridEvaluation
            // 
            this.dataGridEvaluation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridEvaluation.Location = new System.Drawing.Point(305, 50);
            this.dataGridEvaluation.Name = "dataGridEvaluation";
            this.dataGridEvaluation.Size = new System.Drawing.Size(286, 152);
            this.dataGridEvaluation.TabIndex = 1;
            this.dataGridEvaluation.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(97, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Group List";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(415, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "Evaluations";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(157, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "GroupId";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(157, 286);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Evaluation";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(154, 312);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Obtained Marks";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(157, 341);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(30, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "Date";
            // 
            // txtgroup
            // 
            this.txtgroup.Location = new System.Drawing.Point(242, 257);
            this.txtgroup.Name = "txtgroup";
            this.txtgroup.Size = new System.Drawing.Size(200, 20);
            this.txtgroup.TabIndex = 11;
            // 
            // txtevaluation
            // 
            this.txtevaluation.Location = new System.Drawing.Point(242, 283);
            this.txtevaluation.Name = "txtevaluation";
            this.txtevaluation.Size = new System.Drawing.Size(200, 20);
            this.txtevaluation.TabIndex = 12;
            // 
            // txtmarks
            // 
            this.txtmarks.Location = new System.Drawing.Point(242, 309);
            this.txtmarks.Name = "txtmarks";
            this.txtmarks.Size = new System.Drawing.Size(200, 20);
            this.txtmarks.TabIndex = 13;
            // 
            // dateTimedate
            // 
            this.dateTimedate.Location = new System.Drawing.Point(242, 335);
            this.dateTimedate.Name = "dateTimedate";
            this.dateTimedate.Size = new System.Drawing.Size(200, 20);
            this.dateTimedate.TabIndex = 14;
            // 
            // btndone
            // 
            this.btndone.Location = new System.Drawing.Point(353, 374);
            this.btndone.Name = "btndone";
            this.btndone.Size = new System.Drawing.Size(89, 30);
            this.btndone.TabIndex = 15;
            this.btndone.Text = "Done";
            this.btndone.UseVisualStyleBackColor = true;
            this.btndone.Click += new System.EventHandler(this.btndone_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(0, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(73, 13);
            this.linkLabel1.TabIndex = 16;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "BackToHome";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.dataGridGroplist);
            this.panel1.Controls.Add(this.btndone);
            this.panel1.Controls.Add(this.dataGridEvaluation);
            this.panel1.Controls.Add(this.dateTimedate);
            this.panel1.Controls.Add(this.txtmarks);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtevaluation);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtgroup);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(628, 470);
            this.panel1.TabIndex = 17;
            // 
            // GroupEvaluation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(628, 470);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.linkLabel1);
            this.Name = "GroupEvaluation";
            this.Text = "GroupEvaluation";
            this.Load += new System.EventHandler(this.GroupEvaluation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridGroplist)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridEvaluation)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridGroplist;
        private System.Windows.Forms.DataGridView dataGridEvaluation;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtgroup;
        private System.Windows.Forms.TextBox txtevaluation;
        private System.Windows.Forms.TextBox txtmarks;
        private System.Windows.Forms.DateTimePicker dateTimedate;
        private System.Windows.Forms.Button btndone;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Panel panel1;
    }
}